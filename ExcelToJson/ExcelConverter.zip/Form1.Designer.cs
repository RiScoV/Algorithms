﻿namespace ExcelConverter
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.ExcelToDescBtn = new System.Windows.Forms.Button();
            this.LogRichTextBox = new System.Windows.Forms.RichTextBox();
            this.FilePathTextBox = new System.Windows.Forms.TextBox();
            this.Browse = new System.Windows.Forms.Button();
            this.LogTextBox = new System.Windows.Forms.RichTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ExcelToDescBtn
            // 
            this.ExcelToDescBtn.Location = new System.Drawing.Point(615, 380);
            this.ExcelToDescBtn.Name = "ExcelToDescBtn";
            this.ExcelToDescBtn.Size = new System.Drawing.Size(173, 58);
            this.ExcelToDescBtn.TabIndex = 0;
            this.ExcelToDescBtn.Text = "Excel To Desc";
            this.ExcelToDescBtn.UseVisualStyleBackColor = true;
            this.ExcelToDescBtn.Click += new System.EventHandler(this.OnClickExcelToJsonFilesBtn);
            // 
            // LogRichTextBox
            // 
            this.LogRichTextBox.Location = new System.Drawing.Point(12, 45);
            this.LogRichTextBox.Name = "LogRichTextBox";
            this.LogRichTextBox.Size = new System.Drawing.Size(597, 393);
            this.LogRichTextBox.TabIndex = 1;
            this.LogRichTextBox.Text = "Success File Appear here";
            // 
            // FilePathTextBox
            // 
            this.FilePathTextBox.Location = new System.Drawing.Point(12, 12);
            this.FilePathTextBox.Name = "FilePathTextBox";
            this.FilePathTextBox.Size = new System.Drawing.Size(484, 21);
            this.FilePathTextBox.TabIndex = 2;
            // 
            // Browse
            // 
            this.Browse.Location = new System.Drawing.Point(502, 12);
            this.Browse.Name = "Browse";
            this.Browse.Size = new System.Drawing.Size(107, 23);
            this.Browse.TabIndex = 3;
            this.Browse.Text = "Browse";
            this.Browse.UseVisualStyleBackColor = true;
            this.Browse.Click += new System.EventHandler(this.OnClickFindPathBtn);
            // 
            // LogTextBox
            // 
            this.LogTextBox.Location = new System.Drawing.Point(615, 108);
            this.LogTextBox.Name = "LogTextBox";
            this.LogTextBox.Size = new System.Drawing.Size(173, 244);
            this.LogTextBox.TabIndex = 4;
            this.LogTextBox.Text = "Log will Show in Here!";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(615, 81);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(173, 21);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "Log Box";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.LogTextBox);
            this.Controls.Add(this.Browse);
            this.Controls.Add(this.FilePathTextBox);
            this.Controls.Add(this.LogRichTextBox);
            this.Controls.Add(this.ExcelToDescBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ExcelToDescBtn;
        private System.Windows.Forms.RichTextBox LogRichTextBox;
        private System.Windows.Forms.TextBox FilePathTextBox;
        private System.Windows.Forms.Button Browse;
        private System.Windows.Forms.RichTextBox LogTextBox;
        private System.Windows.Forms.TextBox textBox1;
    }
}

