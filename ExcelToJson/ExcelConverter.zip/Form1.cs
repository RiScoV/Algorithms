﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace ExcelConverter
{
    public partial class Form1 : Form
    {
        public string FILE_PATH_SRC = "";
        public string FILE_PATH_DST = "patch/";

        public Form1()
        {
            InitializeComponent();
        }

        private void OnClickExcelToJsonFilesBtn(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(FILE_PATH_SRC))
            {
                MessageBox.Show("올바른 경로를 입력하지 않았습니다!");
                return;
            }

            DirectoryInfo directoryInfo = new DirectoryInfo(FILE_PATH_SRC);
            if(directoryInfo == null)
            {
                MessageBox.Show("파일 디렉토리에서 탐색에 실패하였습니다!");
                return;
            }

            FileInfo[] fileInfos = directoryInfo.GetFiles();
            if (fileInfos == null || fileInfos.Length <= 0)
            {
                MessageBox.Show("탐색된 파일이 없습니다!");
                return;
            }

            ExcelReader excelReader = null;

            this.LogRichTextBox.Clear();
            this.LogRichTextBox.Text += "변환 시작! ... 진행 단계에 들어갑니다.\r\n";
            this.LogRichTextBox.Text += "\r\n";
            this.LogRichTextBox.Text += "\r\n";

            foreach (FileInfo fileInfo in fileInfos)
            {
                if (fileInfo.Exists == false)
                    continue;

                this.LogRichTextBox.Text += string.Format("{0} 변환중...\r\n", fileInfo.Name);

                excelReader = new ExcelReader(FILE_PATH_SRC + fileInfo.Name);
                JArray dataArray = excelReader.GetJsonArray();
                File.WriteAllText(FILE_PATH_DST + string.Format("{0}.json", Path.GetFileNameWithoutExtension(fileInfo.Name)), dataArray.ToString());

                this.LogRichTextBox.Text += string.Format("{0}으로 변환완료...\r\n", Path.GetFileNameWithoutExtension(fileInfo.Name) + ".json" );

                excelReader.Free();
            }

            MessageBox.Show("변환이 완료되었습니다!");
        }

        /// <summary>
        /// 경로 대입 버튼
        /// </summary>
        private void OnClickFindPathBtn(object sender, EventArgs e)
        {
            // 경로찾는 버튼
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.ShowDialog();

            FILE_PATH_SRC = dialog.FileName;
            string fileName = dialog.SafeFileName;
            if(string.IsNullOrEmpty(FILE_PATH_SRC) == false)
            {
                FILE_PATH_SRC = FILE_PATH_SRC.Replace(fileName, string.Empty);
                this.FilePathTextBox.Text = FILE_PATH_SRC;
            }
        }
    }

    public class ExcelReader
    {
        public Excel.Application Application;
        public Excel.Workbooks Workbooks;
        public Excel.Workbook Workbook;
        public Excel.Sheets Sheets;
        public Excel.Worksheet Sheet;
        public Excel.Range Cells;
        public Excel.Range Range;

        public ExcelReader(string filePath)
        {
            this.Application = new Excel.Application();
            this.Workbooks = Application.Workbooks;
            this.Workbook = Application.Workbooks.Add(filePath);
            this.Sheets = this.Workbook.Worksheets;
            this.Sheet = Workbook.Worksheets.Item[1];
            this.Cells = (Excel.Range)Sheet.Cells;
            this.Range = this.Sheet.UsedRange;
        }

        public JArray GetJsonArray()
        {
            JArray rtnArray = new JArray();

            // 변수명 리스트 적출
            List<string> nameList = new List<string>();
            for (int i = 1; i <= Range.Columns.Count; i++)
            {
                nameList.Add(Range.Cells[1, i].Value.ToString());
            }

            //모든 컬럼을 돌며 JArray로 변환.
            int startRow = (this.CheckHasType()) ? 3 : 2;
            for (int row = startRow; row <= Range.Rows.Count; row++)
            {
                var jObject = new JObject();
                for (int col = 1; col <= Range.Columns.Count; col++)
                {
                    jObject.Add(nameList[col - 1], Range.Cells[row, col].Value.ToString());
                }

                //Console.WriteLine(jObject.ToString());
                rtnArray.Add(jObject);
            }

            return rtnArray;
        }

        public bool CheckHasType()
        {
            string[] typeArray = { "int", "float", "double", "string",
                "short", "long", "char", "bool", "uint", "byte"};

            foreach (string type in typeArray)
            {
                if (this.Range.Cells[2, 1].Value.ToString() == type)
                    return true;
            }
            return false;
        }

        public void Free()
        {
            //저장할지 물어보는거 취소.
            this.Application.DisplayAlerts = false;
            this.Application.Quit();

            Marshal.ReleaseComObject(this.Range);
            Marshal.ReleaseComObject(this.Cells);
            Marshal.ReleaseComObject(this.Sheet);
            Marshal.ReleaseComObject(this.Sheets);
            Marshal.ReleaseComObject(this.Workbook);
            Marshal.ReleaseComObject(this.Workbooks);
            Marshal.ReleaseComObject(this.Application);
        }
    }
}
